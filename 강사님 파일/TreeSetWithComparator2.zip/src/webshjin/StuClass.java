package webshjin;

import java.util.HashSet;
import java.util.Set;



public class StuClass {
	private int classNo;
	private Set<Student> stuSet;
	
	public StuClass(int classNo) {
		super();
		this.classNo = classNo;
		this.stuSet = new HashSet<>();
	}

	public Set<Student> getStuSet() {
		return stuSet;
	}

	public void setStuSet(Set<Student> stuSet) {
		this.stuSet = stuSet;
	}

	public int getClassNo() {
		return classNo;
	} 
	
	public void addStudent(Student s) {
		this.stuSet.add(s);
	}
	
	public void outputEntireStudents() {
		for (Student student : this.stuSet) {
			System.out.println(student.toString());
		}
	}

	@Override
	public String toString() {
		return "StuClass [classNo=" + classNo + ", stuSet=" + stuSet + "]";
	}
	
		
	
}
