package webshjin;

public class Student {
	private String stuNo;
	private String name;
	private int score;
	
	public Student(String stuNo, String name, int score) {
		super();
		this.stuNo = stuNo;
		this.name = name;
		this.score = score;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public String getStuNo() {
		return stuNo;
	}
	
	

	@Override
	public int hashCode() {
		return this.stuNo.hashCode();  // 같은 학번일때 같은 해쉬코드가 반환되도록
	}

	@Override
	public boolean equals(Object obj) {
		// 학번이 같으면 같은 학생으로 인식되도록
		boolean result = false;
		
		if (obj instanceof Student) {
			Student tmp = (Student)obj;
			if (this.stuNo.equals(tmp.stuNo)) {
				result = true;
			}
		}
		
		return result;
			
	}

	@Override
	public String toString() {
		return "Student [stuNo=" + stuNo + ", name=" + name + ", score=" + score + "]";
	}

	
}
