package webshjin;

import java.util.Comparator;

public interface Sortable extends Comparator<Student> {

}
