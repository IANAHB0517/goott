package webshjin;

import java.util.Collection;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class TreesetTest {

	public static void main(String[] args) {
		StuClass class1 = new StuClass(1);
		
		
		Student s2 = new Student("230002", "도우너", 34);
		Student s3 = new Student("230003", "마이콜", 56);
		Student s1 = new Student("230001", "둘리", 98);
		Student s4 = new Student("230001", "또치", 77);
		
		class1.addStudent(s1);
		class1.addStudent(s2);
		class1.addStudent(s3);
		class1.addStudent(s4);
		

		class1.outputEntireStudents();
		
		while(true) {
			System.out.print("정렬기준을 입력 (1. 학번순, 2. 이름순 3. 성적순) >> ");
			Scanner sc = new Scanner(System.in);
			int num = sc.nextInt();
			Set<Student> output = new TreeSet<Student>(SortManager.getSortMethod(num));
			output.addAll(class1.getStuSet());
			
			for (Student s : output) {
				System.out.println(s.toString());
			}
		}
		
		
	}

}
