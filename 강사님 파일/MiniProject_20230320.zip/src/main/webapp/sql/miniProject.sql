use jsh;
-- member 테이블 생성
CREATE TABLE `member` (
  `userId` varchar(8) NOT NULL,
  `userPwd` varchar(200) NOT NULL,
  `userEmail` varchar(50) NOT NULL,
  `userMobile` varchar(13) DEFAULT NULL,
  `userGender` varchar(1) NOT NULL,
  `hobbies` varchar(100) DEFAULT NULL,
  `job` varchar(20) DEFAULT NULL,
  `userImg` varchar(100) DEFAULT 'uploadMember/noimage.png',
  `memo` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 패스워드 암호화
select md5('1234');  -- md5 알고리즘으로 암호화
select sha1('1234'); -- sha1 알고리즘으로 암호화
select sha1(md5('1234')); 

-- 모든 회원 조회
select * from pointpolicymember;

-- 회원 가입
-- 회원가입시 이미지가 없을때는 default 값이 들어가야 하므로 sql문
insert into member(userId, userPwd, userEmail, userMobile, userGender, hobbies, job, memo)
 values('abc', sha1(md5('1234')) , 'abc@abc.com', '010-1111-2222', 'M', '', '학생', '');

insert into member(userId, userPwd, userEmail, userMobile, userGender, hobbies, job, memo)
 values(?, sha1(md5(?)), ?, ?, ?, ?, ?, ?);

-- 회원가입시 이미지가 있을때 sql문
insert into member
 values(?, sha1(md5(?)) , ?, ?, ?, ?, ?, ?, ?);

-- 중복된 유저 아이디 검사 sql문
select count(*) as userCnt from member where userId = 'abc';


-- 로그인 처리
select * from member where userId = ? and userPwd = sha1(md5(?));
select * from member where userId = 'abcd' and userPwd = sha1(md5('1234'));

-- 회원 포인트 적립을 위한 테이블 생성
CREATE TABLE `memberpoint` (
  `who` varchar(8) NOT NULL,
  `when` datetime DEFAULT CURRENT_TIMESTAMP,
  `why` varchar(50) DEFAULT NULL,
  `howmuch` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `pointpolicy` (
  `why` varchar(50) NOT NULL,
  `howmuch` int(11) DEFAULT NULL,
  PRIMARY KEY (`why`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 테이블 참조 관계 만들기
ALTER TABLE `jsh`.`memberpoint` 
ADD CONSTRAINT `who_fk`
  FOREIGN KEY (`who`)
  REFERENCES `jsh`.`member` (`userId`)
  ON DELETE CASCADE;
  

alter table memberpoint
add constraint memberpoint_why_fk foreign key(why) references pointpolicy(why);

-- 멤버 포인트 조회
select * from memberpoint;

-- 유저에게 포인트를 부여하는 sql
insert into memberpoint(who, why, howmuch)
values(?, '회원가입', (select howmuch from pointpolicy where why='회원가입'));

-- 회원의 로그인 기록을 저장하는 테이블 생성
CREATE TABLE `jsh`.`latestloginlog` (
  `who` VARCHAR(8) NOT NULL,
  `latestLoginDate` DATETIME NULL DEFAULT now(),
  PRIMARY KEY (`who`));
  
  -- member, latestloginlog 관계지정
  alter table latestloginlog
  add constraint member_userId_fk foreign key(who) references member(userId);
  
  -- 최근 로그인 한 것이 날짜가 바뀌었나?
  -- 회원 가입후 처음 로그인 하면 null
select datediff(now(), (select latestlogindate from latestloginlog where who='dooly')) as diff;
-- 처음 로그인 x, 로그인 하고 날짜가 바뀌었으면 > 0
select datediff(now(), (select latestlogindate from latestloginlog where who='dooly')) as diff;  
-- 처음 로그인 x, 로그인 한 날짜가 바뀌지 않았으면 0
  
-- 처음 로그인 한 사람 로그인 기록 남기는 sql문
insert into latestloginlog(who) values(?);

-- 기존 로그인 기록이 있는 사람 update 하는 sql문
update latestloginlog set latestLoginDate = now() where who = ?;

-- 과거 로그인 했던 기록이 언제였는지(기록이 없다면 -1)
select ifnull(a.diff, -1) as datediff from 
(select datediff(now(), (select latestlogindate from latestloginlog where who='dooly')) as diff) a;

-- 유저 아이디로 회원정보 가져오기 
select * from member where userId = ?;




