package com.miniproj.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.miniproj.member.dao.DBConnection;
import com.miniproj.member.dao.MemberDAOImpl;
import com.miniproj.vodto.BoardVo;
import com.miniproj.vodto.ReadCountProcess;

public class BoardDAOImpl implements BoardDAO {
	private static BoardDAOImpl instance = null;

	private BoardDAOImpl() {
	}

	public static BoardDAOImpl getInstance() {
		if (instance == null) {
			instance = new BoardDAOImpl();
		}

		return instance;
	}

	@Override
	public List<BoardVo> selectEntireBoard() throws NamingException, SQLException {
		List<BoardVo> lst = new ArrayList<>();

		Connection con = DBConnection.dbConnect();

		if (con != null) {
			String q = "select * from board order by no desc";

			PreparedStatement pstmt = con.prepareStatement(q);

			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				lst.add(new BoardVo(rs.getInt("no"), rs.getString("writer"), rs.getString("title"),
						rs.getTimestamp("postDate"), rs.getString("content"), rs.getString("imgFile"),
						rs.getInt("readcount"), rs.getInt("likecount"), rs.getInt("ref"), rs.getInt("step"),
						rs.getInt("reforder")));
			}
			DBConnection.dbClose(rs, pstmt, con);
		}

		return lst;
	}

	@Override
	public int getNextRef() throws NamingException, SQLException {
		int nextRef = 0;

		Connection con = DBConnection.dbConnect();

		if (con != null) {
			String q = "select max(no) + 1 as nextRef from board";

			PreparedStatement pstmt = con.prepareStatement(q);

			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				nextRef = rs.getInt("nextRef");
			}

			DBConnection.dbClose(rs, pstmt, con);
		}

		return nextRef;
	}

	@Override
	public int insertBoard(BoardVo board) throws NamingException, SQLException {
		// 글 등록 -> addPoint (트랜잭션 처리)
		int result = 0;

		Connection con = DBConnection.dbConnect();

		con.setAutoCommit(false); // 트랜잭션 시작

		if (con != null) {
			String q = "insert into board(writer, title, content, imgFile, ref) " + "values(?, ?, ?, ?, ?)";

			PreparedStatement pstmt = con.prepareStatement(q);

			pstmt.setString(1, board.getWriter());
			pstmt.setString(2, board.getTitle());
			pstmt.setString(3, board.getContent());
			pstmt.setString(4, board.getImgFile());
			pstmt.setInt(5, board.getRef());

			// 게시물 등록
			int writeResult = pstmt.executeUpdate();

			// 글쓴이에게 포인트 부여
			int pointResult = MemberDAOImpl.getInance().addPoint(board.getWriter(), "게시판글쓰기", con);

			if (writeResult == 1 && pointResult == 1) {
				con.commit();
				result = 1;
			} else {
				con.rollback();
			}

			con.setAutoCommit(true);

			DBConnection.dbClose(pstmt, con);

		}

		return result;
	}

	@Override
	public BoardVo selectBoardByNo(int no) throws NamingException, SQLException {
		BoardVo board = null;

		Connection con = DBConnection.dbConnect();

		if (con != null) {
			String q = "select * from board where no=?";

			PreparedStatement pstmt = con.prepareStatement(q);
			pstmt.setInt(1, no);

			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				board = new BoardVo(rs.getInt("no"), rs.getString("writer"), rs.getString("title"),
						rs.getTimestamp("postDate"), rs.getString("content"), rs.getString("imgFile"),
						rs.getInt("readcount"), rs.getInt("likecount"), rs.getInt("ref"), rs.getInt("step"),
						rs.getInt("reforder"));
			}
			DBConnection.dbClose(rs, pstmt, con);
		}

		return board;
	}

	/**
	 * ?번 ip주소가 ?번 글을 읽은적이 있냐? return 값 : (하루 이상 1 , 하루이하 0, 읽은적없으면 -1)
	 */
	@Override
	public int withinOneDayOrNot(String ipAddr, int boardNo) throws NamingException, SQLException {
		int result = -1;

		Connection con = DBConnection.dbConnect();

		if (con != null) {
			String q = "select ifNull(timestampdiff(hour, " + "(select readtime from readcountprocess where ipAddr = ? "
					+ "and boardNo = ?), now()) > 24, -1) as diff";

			PreparedStatement pstmt = con.prepareStatement(q);
			pstmt.setString(1, ipAddr);
			pstmt.setInt(2, boardNo);

			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				result = rs.getInt("diff");
			}

			DBConnection.dbClose(rs, pstmt, con);
		}

		return result;
	}
	
	// 트랜잭션 처리용 int withinOneDayOrNot(String ipAddr, int boardNo) 오버로딩
	/*
	 * 
	 *
	 * ?번 ip주소가 ?번 글을 읽은적이 있냐? return 값 : (하루 이상 1 , 하루이하 0, 읽은적없으면 -1)
	 */ 
	public int withinOneDayOrNot(String ipAddr, int boardNo, Connection con) 
			throws NamingException, SQLException {
		int result = -1;

		//Connection con = DBConnection.dbConnect();

		if (con != null) {
			String q = "select ifNull(timestampdiff(hour, " + "(select readtime from readcountprocess where ipAddr = ? "
					+ "and boardNo = ?), now()) > 24, -1) as diff";

			PreparedStatement pstmt = con.prepareStatement(q);
			pstmt.setString(1, ipAddr);
			pstmt.setInt(2, boardNo);

			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				result = rs.getInt("diff");
			}

			//DBConnection.dbClose(rs, pstmt, con);
		}

		return result;
	}

	@Override
	public int updateReadCount(int no) throws NamingException, SQLException {
		int result = 0;

		Connection con = DBConnection.dbConnect();

		if (con != null) {
			String q = "update board set readcount = readcount + 1 where no = ?";

			PreparedStatement pstmt = con.prepareStatement(q);

			pstmt.setInt(1, no);
						
			result = pstmt.executeUpdate();
			
			DBConnection.dbClose(pstmt, con);

		}

		return result;
	}
	
	public int updateReadCount(int no, Connection con) throws NamingException, SQLException {
		int result = 0;

//		Connection con = DBConnection.dbConnect();

		if (con != null) {
			String q = "update board set readcount = readcount + 1 where no = ?";

			PreparedStatement pstmt = con.prepareStatement(q);

			pstmt.setInt(1, no);
						
			result = pstmt.executeUpdate();
			
//			DBConnection.dbClose(pstmt, con);

		}

		return result;
	}

	@Override
	public int insertReadCount(String ipAddr, int boardNo) throws NamingException, SQLException {
		int result = 0;

		Connection con = DBConnection.dbConnect();

		if (con != null) {
			String q = "insert into readcountprocess(ipAddr, boardNo) "
					+ "values (?, ?)";

			PreparedStatement pstmt = con.prepareStatement(q);

			pstmt.setString(1, ipAddr);
			pstmt.setInt(2, boardNo);
						
			result = pstmt.executeUpdate();
			
			DBConnection.dbClose(pstmt, con);

		}

		return result;
	}

	@Override
	public int updateReadTime(String ipAddr, int boardNo) throws NamingException, SQLException {
		int result = 0;

		Connection con = DBConnection.dbConnect();

		if (con != null) {
			String q = "update readcountprocess set readTime = now() "
					+ "where ipAddr=? and boardNo=?";

			PreparedStatement pstmt = con.prepareStatement(q);

			pstmt.setString(1, ipAddr);
			pstmt.setInt(2, boardNo);
						
			result = pstmt.executeUpdate();
			
			DBConnection.dbClose(pstmt, con);

		}

		return result;
	}
	
	public int updateReadTime(String ipAddr, int boardNo, Connection con) throws NamingException, SQLException {
		int result = 0;

//		Connection con = DBConnection.dbConnect();

		if (con != null) {
			String q = "update readcountprocess set readTime = now() "
					+ "where ipAddr=? and boardNo=?";

			PreparedStatement pstmt = con.prepareStatement(q);

			pstmt.setString(1, ipAddr);
			pstmt.setInt(2, boardNo);
						
			result = pstmt.executeUpdate();
			
//			DBConnection.dbClose(pstmt, con);

		}

		return result;
	}

	@Override
	public int transactionprocessforReadCount(ReadCountProcess rcp) throws NamingException, SQLException {
		int result = -1;
		
		Connection con = DBConnection.dbConnect();
		
		con.setAutoCommit(false); // 트랜잭션 시작 지점
		
		if (con != null) {
			int oneday = withinOneDayOrNot(rcp.getIpAddr(), rcp.getBoardNo(), con);
			if (oneday == -1) {
				int insertResult = insertReadCount(rcp.getIpAddr(), rcp.getBoardNo(), con);
				int updateResult = updateReadCount(rcp.getBoardNo(), con);
				
				if (insertResult == 1 && updateResult == 1) {
					con.commit();
					result = 1;
				} else {
					con.rollback();
				}
				
			} else if (oneday == 1) {
				int updateResult1 = updateReadTime(rcp.getIpAddr(), rcp.getBoardNo(), con);
				int updateResult2 = updateReadCount(rcp.getBoardNo(), con);
				
				if (updateResult1 == 1 && updateResult2 == 1) {
					con.commit();
					result = 1;
				} else {
					con.rollback();
				}
			} else {
				result = 1;
			}
		}
		
		con.setAutoCommit(true); // 트랜잭션 종료 지점
		
		DBConnection.dbClose(con);
		return result;
	}

	private int insertReadCount(String ipAddr, int boardNo, Connection con) 
			throws NamingException, SQLException {
		int result = 0;

//		Connection con = DBConnection.dbConnect();

		if (con != null) {
			String q = "insert into readcountprocess(ipAddr, boardNo) "
					+ "values (?, ?)";

			PreparedStatement pstmt = con.prepareStatement(q);

			pstmt.setString(1, ipAddr);
			pstmt.setInt(2, boardNo);
						
			result = pstmt.executeUpdate();
			
//			DBConnection.dbClose(pstmt, con);

		}

		return result;
	}
	
	
	
	
	

}
