package com.miniproj.board.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.miniproj.board.controller.BoardFactory;
import com.miniproj.board.dao.BoardDAO;
import com.miniproj.board.dao.BoardDAOImpl;
import com.miniproj.error.CommonException;
import com.miniproj.vodto.BoardVo;

public class BoardListService implements BoardService {

	@Override
	public BoardFactory action(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		BoardFactory bf = BoardFactory.getInstance();
		
		BoardDAO dao = BoardDAOImpl.getInstance();
		
		try {
			List<BoardVo> lst = dao.selectEntireBoard();
			
			req.setAttribute("boardList", lst);
			
			bf.setRedirect(false);
			bf.setWhereisgo("listAll.jsp");
			
		} catch (NamingException | SQLException e) {
			if (e instanceof NamingException) {
				// NamingException은 개발자 실수이기 때문에 개발자만 보도록 공통 에러페이지(error.jsp)를 만들었고
				// 에러 정보를 error.jsp로 바인딩하여 error.jsp페이지에서 에러 정보를 출력하였다.
				// forward
				
				CommonException ce = new CommonException(e.getMessage(), 99);
//				throw ce; // 강제로 예외를 발생 시킴
				
				ce.setErrorMsg(e.getMessage());
				ce.setStackTrace(e.getStackTrace());
				
				req.setAttribute("error", ce);  // 에러 정보를 가진 CommonException 객체 바인딩
				
				bf.setRedirect(false);
				bf.setWhereisgo("../error.jsp");
				
			} else if (e instanceof SQLException) {
				bf.setRedirect(true);
				bf.setWhereisgo("../index.jsp");
			}
		}
		
		return bf;
	}

}
