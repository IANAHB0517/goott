package com.miniproj.etc;

public class EmailAccount {
	public static String emailAddr = "";  // 본인의 이메일주소
	public static String emailPwd = "";  // 본인의 이메일주소에 대한 패스워드
}
