package webshjin;

public interface Phone {
	
	void sendCall();
	void receiveCall();
}
