package webshjin;

public interface GramLaptop extends Computer, Phone {
	
	

}
