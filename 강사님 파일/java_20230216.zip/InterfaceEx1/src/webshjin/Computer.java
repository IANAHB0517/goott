package webshjin;

public interface Computer {
	
	int computeExpressions(String exp);
    void playingApp();
}	
