package webshjin;

public class MobilePhone implements Phone, Computer, Camera {

	@Override
	public void takePicture() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void zoomIn() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int computeExpressions(String exp) {
		return 0;
	}

	@Override
	public void playingApp() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sendCall() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void receiveCall() {
		// TODO Auto-generated method stub
		
	}

}
