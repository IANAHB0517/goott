package webshjin;

public interface Camera {
	void takePicture();
	void zoomIn();
}
