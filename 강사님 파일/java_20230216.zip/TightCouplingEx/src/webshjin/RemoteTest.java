package webshjin;

public class RemoteTest {

	public static void main(String[] args) {
		Remote 리모컨 = new Remote();
		리모컨.powerOnTv();
	}

}
