package webshjin;

public class TV {

	private String brandName;
	
	
	TV(String brandName) {
		super();
		this.brandName = brandName;
	}


	public void powerOn() {
		System.out.println("tv가 켜집니다");
	}

}
