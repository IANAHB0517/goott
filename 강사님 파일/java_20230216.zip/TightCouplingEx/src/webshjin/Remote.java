package webshjin;

public class Remote {
	private TV tv;
	
	public Remote() {
//		tv = new TV();  // TV 클래스의 내용이 수정되었고 강결합이므로 현재 클래스도 수정해야 한다.
	}
	
	public void powerOnTv() {
		this.tv.powerOn();
	}
	
}
