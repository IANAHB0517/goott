package webshjin;

import java.util.HashSet;
import java.util.Set;

public class SetTest {

	public static void main(String[] args) {
		Korean k1 = new Korean("980101-1234567", "둘리");
		Korean k2 = new Korean("980101-1234567", "둘리");
		
		System.out.println("k1의 해쉬코드 " + k1.hashCode());
		System.out.println("k2의 해쉬코드 " + k2.hashCode());
		
		Set<Korean> set = new HashSet<>();
		set.add(k1);
		set.add(k2);
		
		set.add(new Korean("980101-1234568","둘리"));

		
		
		
		// 같은 대한민국 국민이 Set에 저장된다.(논리적인 오류가 생긴다)
		// k1과 k2의 주소가 다르므로, 다른 객체라 생각해서 저장한것.
		for (Korean ko : set) {
			System.out.println(ko.toString() + ":" + ko.hashCode());
		}
		
		// 이 문제의 본질 : 주민번호와 이름이 같으면 같은 객체로 인식시켜야 함.
		// -> 주민번호와 이름이 같은 객체면 중복 저장이 안되도록
		
		// equals()를 오버라이딩. 주민번호와 이름이 같으면 같은 객체로 인식시켜야 함.
		System.out.println(k1.equals(k2)); // true
		

		// hashCode()를 오버라이딩 하는 법
		
		
	}

}
