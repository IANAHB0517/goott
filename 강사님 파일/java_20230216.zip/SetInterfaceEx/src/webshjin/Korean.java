package webshjin;

public class Korean {
	private String regNo;
	private String name;
	
	Korean(String regNo, String name) {
		super();
		this.regNo = regNo;
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRegNo() {
		return regNo;
	}
	
	

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
//		return super.hashCode();
		return (this.name + this.regNo).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		boolean result = false;
		
		if (obj instanceof Korean) {  // ClassCastException 예외 처리
			Korean tmp = (Korean)obj;
			// 현재객체와 넘겨받은 obj객체의 주민번호와 이름이 같다면 true반환, 아니면 false반환
			if (this.regNo.equals(tmp.regNo) && this.name.equals(tmp.name)) {
				result = true;
			}
		}
		
		return result;
	}

	@Override
	public String toString() {
		return "Korean [regNo=" + regNo + ", name=" + name + "]";
	}
	
	
}
