package webshjin;

public class Student {

}
