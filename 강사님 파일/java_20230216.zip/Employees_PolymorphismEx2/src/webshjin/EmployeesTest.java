package webshjin;

public class EmployeesTest {

	public static void main(String[] args) {
		Department 총무부 = new Department(10, "총무부");
		
		// 아래와 같이 코딩하면 Department객체가 소멸되어도 Employee 객체는 남게 된다.(Aggregation 관계)
		Employee 채치수 = new Permanent("100011001", "채치수", 10, 1000000);
		총무부.addEmployee(채치수);
		
		// 아래와 같이 하면 Depatment 객체가 소멸될 때 PartTimer 객체도 함께 소멸 되어 버린다.(Composition관계)
		총무부.addEmployee(new PartTimer("100011002", "강백호", 10, 5, 10000)); 
		
		총무부.outputEntireEmployees();
	
		Owner 이건희 = new Owner();
//		총무부.addEmployee(이건희);
	}

}
