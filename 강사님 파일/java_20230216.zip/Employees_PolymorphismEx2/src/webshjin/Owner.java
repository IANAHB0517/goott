package webshjin;

public class Owner {

}
