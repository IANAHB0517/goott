package webshjin;

import java.util.Scanner;
//import java.lang.Math;  // java.lang은 기본 패키지(import 생략 가능)

public class StaticInstanceMethod {

	// Static과 non-Static 메서드의 메서드 호출방법 
	public static void main(String[] args) {
		
		// 1) static 키워드가 있는 멤버의 사용 방법 : 클래스명.멤버명()으로 호출
		System.out.println(Math.abs(-3));
		
		
		// 2) non-static(instatnce) : static 키워드가 없는 멤버. 
		// 그 멤버를 가지고 있는 클래스로부터 객체를 만들고, 객체명.멤버명()으로 호출
		
		Scanner sc = new Scanner(System.in); // 객체 생성. 객체명 : sc
		System.out.print("num1 >>>" );
		int num1=sc.nextInt();
		System.out.println(num1);
		
		sc.close();
		sc = null;
		
		
		System.gc();
		System.out.print("num >>>" );
		int num = sc.nextInt();
		System.out.println(num);
		

	}

}
