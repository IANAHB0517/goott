package webshjin;

import java.awt.Frame;
import java.awt.Window;

public class InheritanceEx1 extends Frame{
	
	public InheritanceEx1(String title) {
		super(title);
	}

	public static void main(String[] args) {
		InheritanceEx1 myWindow = new InheritanceEx1("나의 윈도우");
		System.out.println(myWindow.toString());
		
		myWindow.setVisible(true);
	}


}
