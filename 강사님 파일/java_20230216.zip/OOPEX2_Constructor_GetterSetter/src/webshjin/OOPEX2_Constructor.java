package webshjin;

public class OOPEX2_Constructor {

	public static void main(String[] args) {
		
		MobilePhone phone = new MobilePhone();
		System.out.println(phone.hashCode());
		System.out.println(phone.toString());
		
		MobilePhone galaxy = new MobilePhone("삼성", "갤럭시S22", 256);
		System.out.println(galaxy.toString());
		
//		MobilePhone hwa = new MobilePhone("화웨이", 128);
		MobilePhone hwa = new MobilePhone("화웨이", null,  0); // 이렇게 호출하면 생성자의 오버로딩 갯수가 줄어든다.
		System.out.println(hwa.toString());
		
		MobilePhone phone2 = new MobilePhone(null, "아이폰14", 512);
		

		System.out.println(phone2.toString());
		
		System.out.println("🧡🧡");
		
//		phone2.brandName = "애플"; // 외부(다른 클래스에서)에서 멤버 변수의 값을 변경하려고 할 때 (setter 이용) 
		phone2.setBrandName("애플");
		System.out.println(phone2.toString());
		
		if(hwa.setMainMemory(1024)) {
			System.out.println("메모리 업그레이드 성공!");
		} else {
			System.out.println("메모리 업그레이드 실패!");
		}
		System.out.println(hwa.toString());
		
		
		
//		System.out.pritnln(galaxy.brandName);  // 외부(다른클래스)에서 멤버 변수의 값을 얻어오려고 할 때(getter 이용)
		System.out.println(galaxy.getBrandName());
		System.out.println(hwa.getModelName());
		System.out.println(phone2.getMainMemory());
		
	}

}
