package webshjin;

import java.util.Arrays;

public class ArrayEx4 {

	public static void main(String[] args) {
        System.out.println("main메서드의 매개변수 args의 길이 : " + args.length);
		System.out.println(Arrays.toString(args)); 
	}

}
