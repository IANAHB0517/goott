import java.util.Scanner;

public class ArrayEx2 {
	public static void main(String[] args) {
		int[] coinUnit = {500, 100, 50, 10};
		
		// 키보드로부터 숫자나 문자를 입력받을 수 있는 객체 생성(sc)
		Scanner sc = new Scanner(System.in);
		System.out.print("거스름돈 >>> ");  // 2650
		int money = sc.nextInt();
		System.out.println(money);
		
		for(int i = 0; i < coinUnit.length; i++) {
			System.out.println(coinUnit[i] + "원 짜리 동전 : " + (money / coinUnit[i]) + "개");
			money %= coinUnit[i];
		}
		
//		short change = 2680;
//		short[] coins = {500,100,50,10};
//		short[] counts = {0,0,0,0};
//		
//		for (int i = 0; i < coins.length; i++) {
//			counts[i] = (short)(change/coins[i]);
//			change %= coins[i];
//		}
		
		
//		System.out.println("500원짜리" + counts[0] + "개\t" + "100원짜리" + counts[1] + "개\t" + "50원짜리" + counts[2] + "개\t" + "10원짜리" + counts[2] + "개\t");
	}
}
