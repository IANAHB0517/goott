package webshjin;

public class Computer {

}
