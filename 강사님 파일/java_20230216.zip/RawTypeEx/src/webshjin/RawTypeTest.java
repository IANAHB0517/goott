package webshjin;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class RawTypeTest {

	public static void main(String[] args) {
		ArrayList ar = new ArrayList<>(); // raw타입의 ArrayList객체 생성
		
		// raw타입으로 생성된 ArrayList ar에는 모든 데이터타입이 다 저장될 수 있다.
		// ---> 데이터의 타입의 안정성을 보장하지 못한다.
		ar.add(10);
		ar.add(3.14f);
		ar.add(3.1415926535d);
//		ar.add("대한민국");
//		ar.add(new Computer());
		
		
		// Generic 타입으로 사용할 것을 권고
		ArrayList<String> ar2 = new ArrayList<String>();
		ar2.add("스트링만");
		ar2.add("저장됨");
//		ar2.add(new Computer());  에러
		
		
		// Generic 타입은 참조 타입만 사용 가능
//		ArrayList<int> ar3 = new ArrayList<>();
		ArrayList<Integer> ar3 = new ArrayList<>();
		
		
		
		// 위의 형식 보다 아래처럼 인터페이스로 다형성을 구현하여 사용하는 것이 이점이 있다
		List<String> ar4 = new ArrayList<>();
		
		ar4.add("eo");
		
		// 인터페이스를 이용하여 다형성을 구현하여 사용하는 것에 대한 이점
		// List 인터페이스의 하위 다른 클래스로 변경해야 할때 용이. (데이터 타입이 유연해짐)
		// 인터페이스의 특정 구현과 내 코드를 분리하기 위해서.
		
		
		
	}

}
