package webshjin;

public class NotPositiveInteger extends Exception {
	private int errorCode = 503;
	
	public NotPositiveInteger(String msg) {
		super(msg);
	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "에러코드 : " + this.errorCode + ", " + 
				super.getMessage();
				
	}
	
	
}
