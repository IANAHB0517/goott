package webshjin;

import java.util.InputMismatchException;
import java.util.Scanner;

public class CustomExceptionTest {

	public static void main(String[] args) {
		
		
		Integer num = null;
		
		while(true) {
			
			try {
				Scanner sc = new Scanner(System.in);
				System.out.print("양수를 입력하세요 >> ");
				num = sc.nextInt();
				if (num > 0) {
					break;
				} else {
					// 예외 객체를 만들어 던짐 -> 사용자 정의 예외 발생
					throw new NotPositiveInteger("양수가 아닙니다!"); 
				}
			} catch (InputMismatchException e) {
				System.out.println("숫자를 입력 하세요");
			} catch (NotPositiveInteger e) {
				System.out.println("입력한 숫자 " + num + "은 음수입니다");
				System.out.println(e.getMessage());
			} 
		} 
		
		System.out.println(num);
	}

}
