package webshjin;

import java.util.ArrayDeque;
import java.util.Queue;

public class QueueTest {

	public static void main(String[] args) {
		Queue<String> queue = new ArrayDeque<>();
		
		queue.add("기양이");
		queue.add("정우");
		queue.add("상진이");
		
		System.out.println(queue.poll());
		System.out.println(queue.poll());
		System.out.println(queue.poll());
		
	}

}
