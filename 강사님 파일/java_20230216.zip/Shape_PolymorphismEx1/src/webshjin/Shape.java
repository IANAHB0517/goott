package webshjin;



// 추상클래스가 되는 조건 
// 1) class 키워드 앞에 abstract 키워드를 붙인다. (추상 메서드가 없어도 추상 클래스로 만들어짐)
// 2) 클래스의 멤버 메서드 중 하나라도 추상 메서드가 있다면 자동으로 추상 클래스가 되어야 한다.
public abstract class Shape {
	private String name;
	private String color;
	private Point p;
	
//	Shape() { }   // 기본생성
	
	Shape(String name, String color, Point p) {
		super();
		this.name = name;
		this.color = color;
		this.p = p;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public Point getP() {
		return p;
	}

	public void setP(Point p) {
		this.p = p;
	}
	
//	public void draw() {
//		// 상위 클래스인 Shape에서는 draw 메서드를 구현 하지 못한다.
	 	// 왜? 어떤 도형을 어떻게 그려야 할지 모르기 (추상적) 때문이다.
	    // -> 추상메서드로 만든다
//	}
	
	// 추상메서드 : 바디가 없는 메서드
	// 언제가는 구현이 되어야 함.
	public abstract void draw();

//	public String toString() {  // 부모인 Object에게 상속받은 toString()
//		
//	}
	
	// 아래의 메서드는 오버로딩이다. 부모가 물려준 toString()을 오버로딩 한것. 그래서 에러가 없다
	public String toString(int a) {
		return "";
	}
	
	
	// 아래의 메서드는 오버로딩이다. 부모가 물려준 toString()을 오버로딩 한것. 그래서 에러가 없다
	protected String toString(String a) {
		return a;
		
	}

	@Override // 아래의 메서드가 오버라이딩 됨을 컴파일에게 명시
	public String toString() {
		return "Shape [name=" + name + ", color=" + color + ", p=" + p + "]";
	}
	
	
	
	
	
}
