package webshjin;

public class ScoreV2 {

	public static void main(String[] args) {
		Student s1 = new Student("9900001", "홍길동", 98, 75, 34);
		Student s2 = new Student("9900002", "둘리", 45, 33, 76);
		
		System.out.println(s1.toString());
		System.out.println(s2.toString());
		
		System.out.println("전체 총점 :" + Student.getTotalTot());
		System.out.println("전체 총점 :" + Student.getTotalTot());
	
		
		System.out.println(s1.getGrade());
		
		s1.setKor(0);
		
		System.out.println(s1.toString());
		
		System.out.println("전체 총점 :" + Student.getTotalTot());
		System.out.println("전체 총점 :" + Student.getTotalTot());
	
		
	}

}
