// 한 줄 주석
/*
 *여러줄 주석
 *   하나의 자바 프로젝트에는 반드시 프로젝트 명과 같은 이름의 public한 클래스가 있어야 한다.  
 */

public class HelloJava { // HelloJava 클래스의 시작
	public static void main(String[] args) {  // main 메서드(프로그램의  실행 시작점)의 시작
		System.out.println("Hello, Java!");
		System.out.print("배고파~~");
		System.out.println("오늘 머 먹지?");
	}
	
}// HelloJava 클래스의 끝
