package webshjin;


class ParentA {
	private int a = 100;
	
	public int getA() {
		return this.a;
	}
}

class ParentD {
	
}

// 자바에서는 다중상속을 표현하는 문법 자체가 없다. syntax error 
//class ETC extends ParentA ParentD {
//	
//}

public class InheritanceEx2Test extends ParentA {

	public static void main(String[] args) {
		System.out.println(new ParentA().getA());  // 자기 자신의 멤버를 사용
		
		System.out.println(new Child().getA());  // Child 객체의 멤버는 아니지만 상속을 받은 멤버이기에 사용가능
		
		System.out.println(new InheritanceEx2Test().getA());  // Child 객체의 멤버는 아니지만 상속을 받은 멤버이기에 사용가능
		
		
		ParentA objA = new ParentA();
		
		Child objChild = new Child();
		
		
		if (objChild instanceof Child) {  // objChild가 Child의 객체이냐?
			System.out.println("네");
		} else {
			System.out.println("아니오");
		}
		
		if (objChild instanceof ParentA) {  // objChild가 ParentA의 객체이냐? (네 - Child의 부모가 ParentA이기 때문)
			System.out.println("네");
		} else {
			System.out.println("아니오");
		}
		
//		if (objChild instanceof ParentD) {  // objChild가 ParentD의 객체이냐? (상속 관계가 아님) 
//			System.out.println("네");
//		} else {
//			System.out.println("아니오");
//		}
	}

}



class Child extends ParentA{
	
}
