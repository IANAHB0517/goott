package webshjin;

import java.util.Arrays;

/**
 * @Class Name : Dealer
 * @author : Administrator
 * @date : 2023. 2. 8.
 * @packages : webshjin
 * @Description : 딜러
 */
public class Dealer {
	public final static int CARD_NUM = 52;
	private Card[] cardDeck = new Card[CARD_NUM];
	
	private static int curCardCount = 0;

	public Dealer() {
		curCardCount = CARD_NUM;
		int cardIndex = 0;
		for (int cardKind = 1; cardKind <= Card.KIND_MAX; cardKind++) {
			for (int cardNum = 1; cardNum <= Card.NUMBER_MAX; cardNum++) {
				this.cardDeck[cardIndex++] = new Card(cardKind, cardNum);
			}
			
		}
	}
	
	
	/**
	 * @Method Name : pickSpcifyCard,
	 * @작성일 : 2023. 2. 8.,
	 * @작성자 : Administrator,
	 * @param : ,
	 * @반환값 : Card 
	 * 
	*/
//	public Card pickSpcifyCard(int kind, int number) {
//		
//	}
	
	
	/**
	 * @Method Name : shuffleCard,
	 * @작성일 : 2023. 2. 8.,
	 * @작성자 : Administrator,
	 * @param : 없음,
	 * @반환값 : void 
	 * @Description 카드를 섞는다: 
	*/
	public void shuffleCard() {
		for (int i = 0; i < 1000; i++) {
			int index = (int)(Math.random() * curCardCount);
			Card temp = this.cardDeck[0];
			this.cardDeck[0] = this.cardDeck[index];
			this.cardDeck[index] = temp;
		}
	}
	
	
	/**
	 * @Method Name : pickCard,
	 * @작성일 : 2023. 2. 8.,
	 * @작성자 : Administrator,
	 * @param : ,
	 * @반환값 : Card 
	 * @Description : 카드를 한장 뽑아 반환.(뽑은 카드는 null처리) 
	*/
	public Card pickCard() {
		int index = 0;
		Card returnCard = null;
		do {
			index = (int) (Math.random() * CARD_NUM);
			returnCard = this.cardDeck[index];
		} while (returnCard == null);
		
		this.cardDeck[index] = null;
		curCardCount--; 
		return returnCard;
	}
	
	
	public Card pickCardAndRemoveArray() {
		int index = 0;  // 뽑은 카드의 인덱스 변수
		Card returnCard = null;  // 뽑힌 카드
		index = (int) (Math.random() * curCardCount);  // 
		
		returnCard = this.cardDeck[index];
		
		Card[] newCardDeck = new Card[curCardCount-1];  // 새로운 빈 배열 생성
		
		for (int from = 0; from < index; from++) {
			newCardDeck[from] = this.cardDeck[from];
		}
		
		for (int from = index + 1; from < curCardCount; from++) {
			newCardDeck[from - 1] = this.cardDeck[from];
		}
		
		System.out.println("뽑은 카드 : " + returnCard.toString() + ", 카드 갯수 : " + newCardDeck.length + ", [Cards]" + Arrays.toString(newCardDeck));
		
		curCardCount--;
		this.cardDeck = newCardDeck;
		
		return returnCard;
	}
	
	
	/**
	 * @Method Name : displayCard,
	 * @작성일 : 2023. 2. 8.,
	 * @작성자 : Administrator,
	 * @param : 없음,
	 * @반환값 : String
	 * @description : 전체 카드를 반환 
	*/
	public String displayCard() {
		return "전체 카드 갯수 : " + this.cardDeck.length + ", [Cards]" + Arrays.toString(this.cardDeck);
			
	}
	
	
}
