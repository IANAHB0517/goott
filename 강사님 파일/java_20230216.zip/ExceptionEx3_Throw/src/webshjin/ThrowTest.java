package webshjin;

public class ThrowTest {

	public static void main(String[] args) {
		Student s = null;
//		try {
//			s = new Student("980001", "둘리", 12, 45, 100);
//		} catch (IllegalArgumentException e) {
//			System.out.println("국어 점수를 잘못 입력 했습니다");
//		}
		
		s = new Student("980001", "둘리", -12, 45, 100);
		
		System.out.println(s.hashCode());
				
	}

}
