package webshjin;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

public class ArrayListTest {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>();
		
		// 데이터 추가
		list.add(10);
		list.add(30);
		list.add(1, 20);
		
		int a = list.get(2);
		
		Collection<Integer> c = new Stack<>();
		c.add(100);
		c.add(200);
	
		System.out.println("=============== 스택 출력 =============");
		
		Stack tmp = (Stack)c;
		
		System.out.println((Integer)tmp.pop());
		System.out.println((Integer)tmp.pop());
		
		
		
		
		System.out.println("=========================================");
		list.addAll(c);
		
		
		
		System.out.println(list.indexOf(30) + "번째 있음");
		
	
		// 리스트에 있는 모든 자료 출력
		for(Integer i : list) {
			System.out.print(i + "\t");
			
		}
		System.out.println();
		
		
// =============================================================================================
//		// 리스트를 반복(Iterator 객체 이용)
//		// Iterator를 사용하는 이유 : 컬렉션의 종류에 상관없이 데이터를 탐색하는 방법을 
//		// 유지하고 싶을 때 사용
//		for (Iterator iterator = list.iterator(); iterator.hasNext();) {
//			System.out.println(iterator.next());
//			
//		}
		
		
//		LinkedList<Integer> l = new LinkedList<>();
//		for (int i = 0; i < 10000; i++) {
//			l.add(i);
//		}
		
		
//		long startTime = System.currentTimeMillis();
//		for (int i = 0; i < 10000; i++) {
//			System.out.print(l.get(i) + "\t");
//		}
		
//		for (Iterator iterator = l.iterator(); iterator.hasNext();) {
//			System.out.print((Integer) iterator.next() + "\t");
//			
//		}
		
//		for(Integer i : l) {
//			System.out.print(i + "\t");
//		}
//		long endTime = System.currentTimeMillis();
//		
//		System.out.println("\n소요 시간 : " + (endTime - startTime));
//		
		
		
		
	}

}
