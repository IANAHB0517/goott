package webshjin;

public class MobilePhone implements Remoteable {

	@Override
	public void remoteControl(ElectricDevice ed) {
		// TODO Auto-generated method stub
		
	}

}
