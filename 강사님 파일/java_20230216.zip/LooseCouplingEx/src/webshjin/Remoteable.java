package webshjin;

public interface Remoteable {
	void remoteControl(ElectricDevice ed);
}
