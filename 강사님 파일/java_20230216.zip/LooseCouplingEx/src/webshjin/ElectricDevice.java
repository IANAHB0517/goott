package webshjin;

public interface ElectricDevice {
	public void powerOn();
}
