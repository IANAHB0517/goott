package webshjin;

public class RemoteTest {

	public static void main(String[] args) {
		TV tv = new TV("lg");
		
		MultiRemoteController mc = new MultiRemoteController();
		mc.remoteControl(tv);
		
		Computer com = new Computer();
		mc.remoteControl(com);

	}

}
