package webshjin;

public class TV implements ElectricDevice {

	private String brandName;
	
	public TV(String brandName) {
		this.brandName = brandName;
	}
	
	@Override
	public void powerOn() {
		System.out.println(getClass().getName() + "이 켜집니다");
	}

}
