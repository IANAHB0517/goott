import java.util.Arrays;

public class ArrayEx1 {

	public static void main(String[] args) {
		int a;
//		System.out.println(a); // 지역변수는 초기화를 하지 않으면 사용하지 못함
		int[] scores = new int[3]; // 객체는 자동 초기화 된다 [0, 0, 0]
		System.out.println(scores.hashCode());
		
		String[] names = new String[5];
		System.out.println(names);
		
		boolean isOk[] = new boolean[2];
		System.out.println(isOk);
		
		// 배열의 요소에 값 할당
		scores[0] = 45;
		scores[1] = 23;
		scores[2] = 100;
		
		System.out.println(scores[2]);
//		scores[3] = 45; // 런타임에러발생(runtime exception) : 배열의 범위에서 벗어남
		
		// 기존의 scores배열이 참조하던 배열에서 다른 배열로 참조됨
		// new 연산자 : 메모리를 할당하고, 객체를 만들어라.
		scores = new int[4]; 
//		scores = new char[3]; // 에러: 위에서 scores변수는 int[]로 사용하겠다고 선언
		System.out.println(scores.hashCode());
		System.out.println(scores[2]); // 배열도 초기화 되었다. 0
		
		
		// 배열의 각 요소에 값을 할당할때 아래와 같은 방법을 쓰면 편리하다.
		int[] scores2 = {100, 20, 30, 55, 23};
		System.out.println(scores2.hashCode());
		
		String[] heros = {"아이언맨", "스파이더맨", "헐크"};
		
		
		// 배열의 각 요소를 화면에 출력
		for (int i = 0; i < heros.length; i++) {
			System.out.println(heros[i]);
		}
		
		// 자바스크립트의 for (... of ...)과 같은 문법
		for (String hero : heros) {
			System.out.println(hero);
		}
		
		// 배열의 각 요소를 간단하게 출력 . Arrays.toString(배열이름);
		System.out.println(Arrays.toString(scores2));
		
		// 2차원 배열의 선언과 생성
		int[][] arr = new int[3][4];
		
	}

}
