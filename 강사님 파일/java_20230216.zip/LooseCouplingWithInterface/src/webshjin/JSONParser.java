package webshjin;

public class JSONParser implements Parseable {

	@Override
	public void parse(String extension) {
		if (extension.toLowerCase().equals("json")) {
			System.out.println("파싱 가능한 json 파일입니다. 파싱 시작");
		}
	}

}
