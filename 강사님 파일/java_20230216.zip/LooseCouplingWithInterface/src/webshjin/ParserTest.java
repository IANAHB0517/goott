package webshjin;

public class ParserTest {

	public static void main(String[] args) {
		Parseable parser = ParseManager.getParser("date.json");
		parser.parse("json");
		
	}

}
