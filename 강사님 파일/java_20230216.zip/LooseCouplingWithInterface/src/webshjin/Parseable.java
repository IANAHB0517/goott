package webshjin;

public interface Parseable {
	public abstract  void parse(String extension);
}
