package webshjin;

public class XMLParser implements Parseable {

	@Override
	public void parse(String extension) {
		if (extension.toLowerCase().equals("xml")) {
			System.out.println("파싱 가능한 xml 파일입니다.. 파싱중");
			
			
		}
	}

}
