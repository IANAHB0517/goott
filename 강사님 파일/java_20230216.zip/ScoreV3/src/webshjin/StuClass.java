package webshjin;

public class StuClass {
	private int no;   // 반 번호
	private String className;   // 과정명
	private Student[] stuList;  // 학생 목록 (포함관계)
	private int totalTot;  // 학생 전체 총점
	private float totalAvg; // 학생 전체 평균
	
	public static final int STUDENT_COUNT = 3;  // 학생을 담는 배열의 길이 (상수)
	
	public StuClass(int no, String className) {
		this.no = no;
		this.className = className;
		this.stuList = new Student[STUDENT_COUNT];
	}
	
	public StuClass(int no, String className, Student[] stuList) {
		this.no = no;
		this.className = className;
		this.stuList = stuList;
	}
	
	// getter
	public int getNo() {
		return this.no;
	}
	
	public String getClassName() {
		return this.className;
	}
	
	public Student[] getStuList() {
		return this.stuList;
	}
	
	// setter 
	public void setClassName(String className) {
		this.className = className;
	}
	
	// 학생 한명을 받아 stuList 배열의 no번째 배열에 추가
	public void addStudent(Student student, int no) {
		this.stuList[no] = student;
	}
	
	
	public void outputEntireStudents() {
		ScoreV3 sc = new ScoreV3();
		for (int i = 0; i < sc.getCurSavedStudentCnt() ; i++) {
			System.out.println(this.stuList[i].toString());
		}
	}
	
	// 학생들의 전체 총점
	public int calcTotalTot() {
		this.totalTot = 0;
		ScoreV3 sc = new ScoreV3();
		for(int i = 0; i < sc.getCurSavedStudentCnt(); i++) {
			this.totalTot += this.stuList[i].getTot();
		}
		
		return this.totalTot;
	}
	
	public float calcTotalAvg() {
		ScoreV3 sc = new ScoreV3();
		this.totalAvg = this.totalTot / 3 / (float)(sc.getCurSavedStudentCnt());
		this.totalAvg = Math.round(totalAvg * 100) / 100;
		return this.totalAvg;
	}
	
	void findStudentByNo(String stuNo) {
		boolean isFind = false;
		// stuNo학번을 가진 학생을 this.stuList(배열)에서 검색
		for (Student s : this.stuList)  {
			if (stuNo.equals(s.getStuNo())) {
				System.out.println("******************** 검색된 학생 정보 ******************");
				System.out.println(s.toString());
				isFind = true;
			}
		}
		
		if (!isFind) {
			System.out.println("******************** 검색된 학생 정보 없습니다!!!! ******************");
		}
	}
	
	public String toSting() {
		return "반 번호 : " + this.no + ", "
				+ "과정명 : " + this.className;
	}
	
}
