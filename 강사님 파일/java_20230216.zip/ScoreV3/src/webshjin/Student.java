package webshjin;


public class Student {
	private String stuNo;
	private String stuName;
	private int kor;
	private int eng;
	private int math;
	private int tot;
	private float avg;
	private char grade;
	
//	private static int totalTot;
	
	public Student(String stuNo, String stuName, int kor, int eng, int math) {
		this.stuNo = stuNo;
		this.stuName = stuName;
		
			this.kor = kor;
		 
		this.eng = eng;
		this.math = math;

		setTot();
		setAvg();
		setGrade();
		
//		totalTot += this.tot;

	}
	
	
//	public static int getTotalTot() {
//		return totalTot;
//	}
	
	
	
	
	
	// getter

	public String getStuNo() {
		return stuNo;
	}

	
	public String getStuName() {
		return stuName;
	}

	public int getKor() {
		return kor;
	}

	public int getEng() {
		return eng;
	}

	public int getMath() {
		return math;
	}

	public int getTot() {
		return tot;
	}

	public float getAvg() {
		return avg;
	}

	public char getGrade() {
		return grade;
	}
	
	
	
	// setter
	
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public void setKor(int kor) {
		if (kor >= 0 && kor <= 100) {
			this.kor = kor;
			setTot(); // 총점 다시 구하기
			setAvg(); // 평균 다시 구하기
			setGrade(); // 등급 다시 구하기
		}
		
		
	}
	
	public void setEng(int eng) {
		if (eng >= 0 && eng <= 100) {
			this.eng = eng;
			setTot(); // 총점 다시 구하기
			setAvg(); // 평균 다시 구하기
			setGrade(); // 등급 다시 구하기
		}
	}
	
	public void setMath(int math) {
		if (math >= 0 && math <= 100) {
			this.math = math;
			setTot(); // 총점 다시 구하기
			setAvg(); // 평균 다시 구하기
			setGrade(); // 등급 다시 구하기
		}
	}
		
	
	public void setTot() {
		this.tot = this.kor + this.eng + this.math;
	}
	
	public void setAvg() {
		this.avg = (float)this.tot / 3;
	}
	
	public void setGrade() {
		switch ((int)(Math.floor(this.avg/10d))) {
		case 10:
		case 9:
			this.grade = 'A';
			break;
		case 8:
			this.grade = 'B';
			break;
		case 7:
			this.grade = 'C';
			break;
		case 6:
			this.grade = 'D';
			break;
		
		default:
			this.grade = 'F';
			break;
		}
	}
 	
	public String toString() {
		return "학번 : " + this.stuNo + ","
				+ "이름 : " + this.stuName + ","
				+ "국어 : " + this.kor + ","  
				+ "영어 : " + this.eng + ","
				+ "수학 : " + this.math + ", "
				+ "총점 : " + this.tot + ", "
				+ "평균 : " + this.avg + ", "
				+ "학점 : " + this.grade;
	
	}
	
	
	
}
